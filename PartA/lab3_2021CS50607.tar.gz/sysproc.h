#define FG 0
#define BG 1
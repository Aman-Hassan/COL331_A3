<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="tileset2" tilewidth="32" tileheight="32" tilecount="225" columns="15">
 <image source="tiles2.png" width="480" height="480"/>
</tileset>

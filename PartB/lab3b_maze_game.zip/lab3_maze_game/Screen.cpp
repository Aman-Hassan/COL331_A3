#include "Screen.h"

LScreen::LScreen(LWindow &window) : window(window) {}
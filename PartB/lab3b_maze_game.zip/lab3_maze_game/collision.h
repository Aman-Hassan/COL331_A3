#include <SDL2/SDL.h>

// Box collision detector
bool checkCollision(SDL_Rect a, SDL_Rect b);
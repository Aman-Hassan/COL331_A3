<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="tileset" tilewidth="32" tileheight="32" tilecount="2240" columns="56">
 <image source="tileset.png" width="1792" height="1280"/>
</tileset>

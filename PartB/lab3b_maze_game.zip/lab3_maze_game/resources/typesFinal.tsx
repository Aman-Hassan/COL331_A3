<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="typesFinal" tilewidth="32" tileheight="32" tilecount="400" columns="20">
 <image source="typesEncoding.png" width="640" height="640"/>
</tileset>

struct playerStateUpdate
{

    float health;
    int money;
    int points;
    int pointsIfTask;
};
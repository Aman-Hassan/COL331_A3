<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="newTileset" tilewidth="80" tileheight="80" tilecount="12" columns="4">
 <image source="tiles.png" width="320" height="240"/>
</tileset>
